module.exports = async globalConfig => {
  testServer.close();
};
