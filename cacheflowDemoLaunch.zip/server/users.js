const users = {
  name: 'walker',
  age: 26
}

module.exports = users;